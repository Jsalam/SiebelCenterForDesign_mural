import { Object3D } from '../../../src/Three';

export class OBJExporter {

	constructor();

	parse( object: Object3D ): string;

}
