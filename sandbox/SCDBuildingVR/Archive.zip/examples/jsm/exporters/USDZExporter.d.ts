import { Object3D } from '../../../src/Three';

export class USDZExporter {

	constructor();

	parse( scene: Object3D ): Uint8Array;

}
