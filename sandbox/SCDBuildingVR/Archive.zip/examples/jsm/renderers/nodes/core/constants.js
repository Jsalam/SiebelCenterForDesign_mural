export const NodeType = {
	Float: 'float',
	Vector2: 'vec2',
	Vector3: 'vec3',
	Vector4: 'vec4',
	Matrix3: 'matrix3',
	Matrix4: 'matrix4'
};
