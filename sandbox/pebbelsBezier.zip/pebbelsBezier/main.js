/**
 * This code draws the silhoutte of pebbles for the SCD mural given a file of node values 
 */
let data;
let pebbles = [];

let main = function(p5) {

    // p5.preload = function() {
    //     data = p5.loadTable("files/nodeValue_test01.csv",
    //         "csv", "header", input => { console.log(input); });
    // }

    p5.setup = function() {
        p5.createCanvas(p5.displayWidth, 800);

        DOM.init();


    }

    /**
     * This function is invoked in DataWrangler
     */
    main.init = function() {
        data = DataWrangler.table;

        // Instantiation
        const count = 0
        for (let i = count; i < count + DataWrangler.table.getRowCount(); i++) {
            let temp = new Pebble(5);
            temp.axesSetup(200 + (360 * i), 360, 150, data.columns, 80);
            temp.idSetup(data.rows[i]);
            pebbles.push(temp);
        }

        // Placement
        let nCol = 10
        for (let i = 0; i < 5; i++) {
            for (let j = 0; j < nCol; j++) {
                // From 2D array to 1D array
                let index = nCol * i + j
                pebbles[index].setPositionAxes(250 + (300 * i), 250 + (300 * j));
            }
        }

        alert(DataWrangler.table.getRowCount() + " datapoints imported");
    }

    p5.draw = function() {
        p5.background(240);

        if (!DataWrangler.table) {
            p5.text("No data loaded yet", 100, 100)
        }
        for (let i = 0; i < pebbles.length; i++) {
            const tNode = pebbles[i];
            tNode.displayRow(data.rows[i].obj);
        }
    }
}

var gp5 = new p5(main, "model");