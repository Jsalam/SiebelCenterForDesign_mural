class DataWrangler {

    static makeTable(data) {
        DataWrangler.table = new p5.Table();
        let columns = ["ChronologicalValue", "InnovationTitle", "InnovationTypes_A", "Colleges_B", "Departments_C", "Decade_D", "People_E"]
        for (const colName of columns) {
            DataWrangler.table.addColumn(colName)
        }

        for (const cluster of data) {
            for (const node of cluster.nodes) {
                let row = DataWrangler.table.addRow();

                row.setString("ChronologicalValue", cluster.clusterID + "-" + node.id);

                row.setString("InnovationTitle", node.nodeLabel);

                let tmpString = node.nodeAttributes.Primary_ToI
                let tmpStringB = node.nodeAttributes.Secondary_ToI
                let types = 1;
                if (tmpStringB.length > 0) types++;
                row.setNum("InnovationTypes_A", types);

                row.setNum("Colleges_B", node.nodeAttributes.N_colleges);

                row.setNum("Departments_C", node.nodeAttributes.N_departments);

                tmpString = node.nodeAttributes.Date_or_Decade
                let tokens = tmpString.split('-')
                row.setNum("Decade_D", tokens[0]);

                tmpString = node.nodeAttributes.Faculty_Staff_Graduate_Undergrad
                tokens = tmpString.split(',')
                row.setNum("People_E", tokens.length);
            }
        }

        main.init();
    }

    static printTable() {
        //print the results
        console.log(DataWrangler.table);
    }

    static saveTable() {
        gp5.saveTable(DataWrangler.table, "dataForPebbles.csv")
    }
}

DataWrangler.dataOut;
DataWrangler.table;