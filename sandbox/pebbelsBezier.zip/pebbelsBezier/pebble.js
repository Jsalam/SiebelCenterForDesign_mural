class Pebble {
    constructor(steps) {
        this.axes = [];
        this.steps = steps;
        this.angle = Math.PI * 2 / steps;
        this.armLength;

        // identification
        this.id;
        this.innovationTitle;

        // centerpoint
        this.pos;

        // for JSON
        this.bezierPoints;
    }

    /** Creating instances of each axis */
    /**
     * 
     * @param {number} x x position
     * @param {number} y y position
     * @param {number} length length in pixels
     * @param {object} labels table headers
     * @param {*} centerOffset offset from the xy centert
     */
    axesSetup(x, y, length, labels, centerOffset) {
        this.pos = gp5.createVector(x, y);
        //InnovationTypes_A
        this.axes[0] = new Axis(0, 7, x, y, length, (this.angle * 0) - Math.PI / 2, labels[0 + 2], centerOffset);
        //,Colleges_B
        this.axes[1] = new Axis(0, 7, x, y, length, (this.angle * 1) - Math.PI / 2, labels[1 + 2], centerOffset);
        //,Departments_C
        this.axes[2] = new Axis(0, 6, x, y, length, (this.angle * 2) - Math.PI / 2, labels[2 + 2], centerOffset);
        //,Decade_D
        this.axes[3] = new Axis(1870, 2020, x, y, length, (this.angle * 3) - Math.PI / 2, labels[3 + 2], centerOffset);
        //,People_E
        this.axes[4] = new Axis(0, 7, x, y, length, (this.angle * 4) - Math.PI / 2, labels[4 + 2], centerOffset);
    }

    idSetup(data) {
        this.id = data.obj.ChronologicalValue;
        this.innovationTitle = data.obj.InnovationTitle;
    }

    /** Displaying row  values */
    displayRow(row) {
        this.axes[0].setValue(row.InnovationTypes_A);
        this.axes[1].setValue(row.Colleges_B);
        this.axes[2].setValue(row.Departments_C);
        this.axes[3].setValue(row.Decade_D);
        this.axes[4].setValue(row.People_E);

        for (const axis of this.axes) {
            axis.show();
        }

        this.drawBezier(this.axes[0].valPosition, this.axes[1].valPosition,
            this.axes[2].valPosition, this.axes[3].valPosition,
            this.axes[4].valPosition, 50);

        //  center point
        gp5.circle(this.pos.x, this.pos.y, 10, 10);
    }

    setPositionAxes(posX, posY) {
        this.pos.x = posX;
        this.pos.y = posY;
        for (const axes of this.axes) {
            axes.setPosition(posX, posY)
        }
    }

    drawBezier(p1, p2, p3, p4, p05, armLength) {
        this.armLength = armLength;
        let arm = gp5.createVector(0, armLength)
        let cp0 = gp5.createVector(p1.x, p1.y);
        let cp1 = gp5.createVector(p1.x, p1.y);
        let cp2 = gp5.createVector(p2.x, p2.y);
        let cp3 = gp5.createVector(p3.x, p3.y);
        let cp4 = gp5.createVector(p4.x, p4.y);
        let cp05 = gp5.createVector(p05.x, p05.y);

        for (var x = 0; x < 5; x++) {}
        // first control point
        arm.rotate(-Math.PI / 2);
        let cp1b = cp0.add(arm);

        // second A and B control point
        arm.rotate((gp5.PI + gp5.TWO_PI / this.steps));
        let cp2a = p5.Vector.add(cp2, arm);
        arm.rotate(gp5.PI)
        let cp2b = p5.Vector.add(cp2, arm);

        // third A and B control point
        arm.rotate(gp5.PI + gp5.TWO_PI / this.steps)
        let cp3a = p5.Vector.add(cp3, arm);
        arm.rotate(gp5.PI)
        let cp3b = p5.Vector.add(cp3, arm);

        // fourth A and B control point
        arm.rotate(gp5.PI + gp5.TWO_PI / this.steps)
        let cp4a = p5.Vector.add(cp4, arm);
        arm.rotate(gp5.PI)
        let cp4b = p5.Vector.add(cp4, arm);

        // fifth A and B control point
        arm.rotate(gp5.PI + gp5.TWO_PI / this.steps)
        let cp5a = p5.Vector.add(cp05, arm);
        arm.rotate(gp5.PI)
        let cp5b = p5.Vector.add(cp05, arm);

        // last control point
        arm.rotate(gp5.PI + gp5.TWO_PI / this.steps)
        let cp1a = cp1.add(arm);

        var vecsA = [cp2a, cp3a, cp4a, cp5a, cp1a];
        var vecsB = [cp1b, cp2b, cp3b, cp4b, cp5b];
        var vecsC = [p2, p3, p4, p05, p1];

        gp5.stroke('black');
        gp5.beginShape();
        gp5.vertex(p1.x, p1.y);
        for (var i = 0; i < 5; i++) {
            gp5.bezierVertex(vecsB[i].x, vecsB[i].y, vecsA[i].x, vecsA[i].y, vecsC[i].x, vecsC[i].y);
        }
        gp5.endShape();

        gp5.noStroke();
        gp5.text(this.id + '\n' + this.innovationTitle, this.pos.x, this.pos.y + 20)

        // noFill();
        gp5.stroke('orange');
        gp5.line(p1.x, p1.y, cp1a.x, cp1a.y);
        gp5.line(p2.x, p2.y, cp2a.x, cp2a.y);
        gp5.line(p2.x, p2.y, cp2b.x, cp2b.y);
        gp5.line(p3.x, p3.y, cp3a.x, cp3a.y);
        gp5.line(p3.x, p3.y, cp3b.x, cp3b.y);
        gp5.line(p4.x, p4.y, cp4a.x, cp4a.y);
        gp5.line(p4.x, p4.y, cp4b.x, cp4b.y);
        gp5.line(p05.x, p05.y, cp5a.x, cp5a.y);
        gp5.line(p05.x, p05.y, cp5b.x, cp5b.y);
        gp5.line(p1.x, p1.y, cp1b.x, cp1b.y);


        // For JSON
        var anchorsOrg = [p1, p2, p3, p4, p05];
        var anchorsEnd = [p2, p3, p4, p05, p1];
        this.bezierPoints = { "anchorsOrg": anchorsOrg, "anchorsEnd": anchorsEnd, "cPointsOrg": vecsA, "cPointsEnd": vecsB };

    }

    getJSON() {
        let rtn = {
            id: this.id,
            innovationTitle: this.innovationTitle,
            arm: this.armLength,
            center: { x: this.pos.x, y: this.pos.y },
            points: []
        };

        // points is a colecction of arrays of bezierPoints
        for (let i = 0; i < this.bezierPoints.anchorsOrg.length; i++) {
            //for (let i = 0; i < 1; i++) {

            let tmp = {
                orgX: this.bezierPoints.anchorsOrg[i].x,
                orgY: this.bezierPoints.anchorsOrg[i].y,
                orgControlX: this.bezierPoints.cPointsOrg[i].x,
                orgControlY: this.bezierPoints.cPointsOrg[i].y,
                endControlX: this.bezierPoints.cPointsEnd[i].x,
                endControlY: this.bezierPoints.cPointsEnd[i].y,
                endX: this.bezierPoints.anchorsEnd[i].x,
                endY: this.bezierPoints.anchorsEnd[i].y,
            }

            rtn.points.push(tmp)
        }

        return rtn;
    }
}